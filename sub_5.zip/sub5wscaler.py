from collections import Counter
import numpy as np
import os
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score, log_loss, confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier
from sklearn.svm import SVC
import matplotlib.pyplot as plt


# Path to the main directory containing Opcode files
opcodes_dir = r"C:\Users\PHILLIPA\Documents\6530 APT groups\sub_5\Opcodes"

# Lists to store extracted opcodes and labels
opcodes_samples = []
labels = []

# Traverse through each subfolder (APT group)
for root, dirs, files in os.walk(opcodes_dir):
    if root != opcodes_dir:  # Skip the main directory
        apt_name = os.path.basename(root)  
        for file in files:
            file_path = os.path.join(root, file)
            try:
                # Read the opcodes from the file
                with open(file_path, 'r') as f:
                    opcodes = f.read().strip().split()  # Split into individual opcodes
                    opcodes_samples.append(opcodes)  # Append the opcodes
                    labels.append(apt_name)  # Append the APT group name as the label
            except Exception as e:
                print(f"Error reading {file_path}: {e}")

# Feature extraction function with metadata tracking
def extract_features_with_metadata(opcode_sequences):
    features = []
    metadata = {
        "Opcode Frequency": [],
        "2-Grams": [],
        "Entropy and Diversity": [],
        "Control Flow": []
    }
    column_index = 0  # Tracks column indices dynamically

    # Define maximum lengths for fixed-size features
    max_opcodes = 256  # Maximum number of unique opcodes
    max_n_grams = 256  # Maximum number of unique 2-grams
    control_flow_opcodes = ["JMP", "CALL", "RET", "JNZ", "JE"]

    for opcodes in opcode_sequences:
        sample_features = []

        # 1. Opcode Frequency
        opcode_freq = Counter(opcodes)
        freq_values = [opcode_freq.get(op, 0) for op in range(max_opcodes)]  # Pad/truncate to max_opcodes
        sample_features.extend(freq_values)
        metadata["Opcode Frequency"].extend(range(column_index, column_index + len(freq_values)))
        column_index += len(freq_values)

        # 2. 2-Grams
        n_grams = [tuple(opcodes[i:i+2]) for i in range(len(opcodes)-1)]
        n_gram_freq = Counter(n_grams)
        n_gram_values = [n_gram_freq.get(ng, 0) for ng in range(max_n_grams)]  # Pad/truncate to max_n_grams
        sample_features.extend(n_gram_values)
        metadata["2-Grams"].extend(range(column_index, column_index + len(n_gram_values)))
        column_index += len(n_gram_values)

        # 3. Entropy and Diversity
        total = sum(opcode_freq.values())
        entropy = -sum((count / total) * np.log2(count / total) for count in opcode_freq.values()) if total > 0 else 0
        diversity = len(opcode_freq)
        sample_features.extend([entropy, diversity])  # Fixed-size features
        metadata["Entropy and Diversity"].extend(range(column_index, column_index + 2))
        column_index += 2

        # 4. Control Flow Opcodes
        control_flow_freq = [opcode_freq.get(op, 0) for op in control_flow_opcodes]  # Fixed-size control flow features
        sample_features.extend(control_flow_freq)
        metadata["Control Flow"].extend(range(column_index, column_index + len(control_flow_freq)))
        column_index += len(control_flow_freq)

        features.append(sample_features)
    
    # Convert features to a fixed-size matrix
    feature_matrix = np.array(features)
    return feature_matrix, metadata

# Extract features and metadata
feature_matrix, feature_metadata = extract_features_with_metadata(opcodes_samples)
features_df = pd.DataFrame(feature_matrix)
features_df.fillna(0, inplace=True)  # Replace NaN with 0

# Convert labels to numeric
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(labels)


# Train-test split
X_train, X_test, y_train, y_test = train_test_split(features_df, y, test_size=0.2, random_state=42, stratify=y)

# Forward Stepwise Selection
def forward_stepwise_selection(X_train, y_train, X_test, y_test, feature_categories, base_model):
    selected_features = []
    best_log_loss = float('inf')

    for category_name, feature_indices in feature_categories.items():
        # Ensure indices are within bounds
        feature_indices = [idx for idx in feature_indices if idx < X_train.shape[1]]

        # Combine current features with candidate features
        candidate_features = selected_features + feature_indices

        # Subset the features
        X_train_candidate = X_train.iloc[:, candidate_features]
        X_test_candidate = X_test.iloc[:, candidate_features]

        # Train the model
        base_model.fit(X_train_candidate, y_train)
        y_pred_probs = base_model.predict_proba(X_test_candidate)
        current_log_loss = log_loss(y_test, y_pred_probs)

        if current_log_loss < best_log_loss:
            best_log_loss = current_log_loss
            selected_features = candidate_features
            print(f"Selected {category_name}. Current best log-loss: {best_log_loss}")
        else:
            print(f"{category_name} did not improve the log-loss.")

    return selected_features

# Forward Stepwise Selection with XGBoost
xgb_classifier = XGBClassifier()
selected_features = forward_stepwise_selection(
    X_train, y_train, X_test, y_test, feature_metadata, xgb_classifier
)

# Use selected features for final training and evaluation
X_train_selected = X_train.iloc[:, selected_features]
X_test_selected = X_test.iloc[:, selected_features]

# XGBoost Classifier
xgb_classifier.fit(X_train_selected, y_train)
xgb_pred = xgb_classifier.predict(X_test_selected)
print("XGBoost Classification Report:\n", classification_report(y_test, xgb_pred))
# Accuracy for XGBoost
xgb_accuracy = accuracy_score(y_test, xgb_pred)
print(f"XGBoost Accuracy: {xgb_accuracy:.2f}")
# Confusion Matrix for XGBoost
xgb_cm = confusion_matrix(y_test, xgb_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=xgb_cm)
disp.plot()
plt.title("Confusion Matrix: XGBoost")
plt.show()

# Random Forest Classifier
rf_classifier = RandomForestClassifier()
rf_classifier.fit(X_train_selected, y_train)
rf_pred = rf_classifier.predict(X_test_selected)
print("Random Forest Classification Report:\n", classification_report(y_test, rf_pred))
# Accuracy for Random Forest
rf_accuracy = accuracy_score(y_test, rf_pred)
print(f"Random Forest Accuracy: {rf_accuracy:.2f}")
# Confusion Matrix for Random Forest
rf_cm = confusion_matrix(y_test, rf_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=rf_cm)
disp.plot()
plt.title("Confusion Matrix: Random Forest")
plt.show()


# Support Vector Machine Classifier (with scaling)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_selected)
X_test_scaled = scaler.transform(X_test_selected)

svm_classifier = SVC(probability=True)
svm_classifier.fit(X_train_scaled, y_train)
svm_pred = svm_classifier.predict(X_test_scaled)
print("SVM Classification Report:\n", classification_report(y_test, svm_pred))
# Accuracy for SVM
svm_accuracy = accuracy_score(y_test, svm_pred)
print(f"SVM Accuracy: {svm_accuracy:.2f}")
# Confusion Matrix for SVM
svm_cm = confusion_matrix(y_test, svm_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=svm_cm)
disp.plot()
plt.title("Confusion Matrix: SVM")
plt.show()

# Bagging with XGBoostbagging_classifier = BaggingClassifier(estimator=XGBClassifier(), n_estimators=10, random_state=42)
bagging_classifier = BaggingClassifier(estimator=XGBClassifier(), n_estimators=10, random_state=42)
bagging_classifier.fit(X_train_selected, y_train)
bagging_pred = bagging_classifier.predict(X_test_selected)
print("Bagging XGBoost Classification Report:\n", classification_report(y_test, bagging_pred))
# Accuracy for Bagging XGBoost
bagging_accuracy = accuracy_score(y_test, bagging_pred)
print(f"Bagging XGBoost Accuracy: {bagging_accuracy:.2f}")
# Confusion Matrix for Bagging XGBoost
bagging_cm = confusion_matrix(y_test, bagging_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=bagging_cm)
disp.plot()
plt.title("Confusion Matrix: Bagging XGBoost")
plt.show()
