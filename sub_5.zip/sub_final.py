from collections import Counter
import numpy as np
import os
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, classification_report, accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC

# Path to the Opcodes directory
opcodes_dir = r"C:\Users\MCTI Student\Desktop\Opcodes"

# Lists to store extracted opcodes and labels
opcodes_samples = []
labels = []

# Traverse through each subfolder (APT group)
for root, dirs, files in os.walk(opcodes_dir):
    if root != opcodes_dir:  # Skip the main directory
        apt_name = os.path.basename(root)  # APT group name is the folder name
        for file in files:
            file_path = os.path.join(root, file)
            try:
                # Read the opcodes from the file
                with open(file_path, 'r') as f:
                    opcodes = f.read().strip().split()  # Split into individual opcodes
                    opcodes_samples.append(opcodes)  # Append the opcodes
                    labels.append(apt_name)  # Append the APT group name as the label
            except Exception as e:
                print(f"Error reading {file_path}: {e}")

# Feature extraction function
def extract_features(opcode_sequences):
    features = {
        "Opcode Frequency": [],
        "N-grams": [],
        "Entropy": [],
        "Diversity": []
    }
    for opcodes in opcode_sequences:
        # Opcode Frequency
        opcode_freq = Counter(opcodes)
        features["Opcode Frequency"].append(list(opcode_freq.values()))

        # 2-Grams
        n_grams = [tuple(opcodes[i:i+2]) for i in range(len(opcodes)-1)]
        n_gram_freq = Counter(n_grams)
        features["N-grams"].append(list(n_gram_freq.values()))

        # Entropy
        total = sum(opcode_freq.values())
        entropy = -sum((count / total) * np.log2(count / total) for count in opcode_freq.values()) if total > 0 else 0
        features["Entropy"].append([entropy])

        # Diversity (unique opcode count)
        diversity = len(opcode_freq)
        features["Diversity"].append([diversity])

    # Pad variable-length features
    for key in ["Opcode Frequency", "N-grams"]:
        max_length = max(len(f) for f in features[key])  # Find the maximum length
        padded_features = [
            f + [0] * (max_length - len(f)) for f in features[key]
        ]  # Pad with zeros
        features[key] = np.array(padded_features)

    # Convert fixed-length features to arrays
    features["Entropy"] = np.array(features["Entropy"])
    features["Diversity"] = np.array(features["Diversity"])
    return features

# Extract features from the opcodes
raw_features = extract_features(opcodes_samples)

# Combine features into a dictionary
features = {key: np.array(value) for key, value in raw_features.items()}

# Convert labels to numeric
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(labels)

# Forward stepwise feature selection
def forward_stepwise_selection(features, y):
    selected_features = []
    remaining_features = {name: data for name, data in features.items()}
    current_logloss = np.inf  # Initialize with a high log loss
    step = 1
    while remaining_features:
        print(f"\nStep {step}: Evaluating feature subsets...")
        best_subset = None
        best_logloss = current_logloss

        for name, data in remaining_features.items():
            # Combine selected features with the current subset
            if selected_features:
                X_combined = np.hstack([features[cat] for cat in selected_features] + [data])
            else:
                X_combined = data

            # Train-test split
            X_train, X_test, y_train, y_test = train_test_split(
                X_combined, y, test_size=0.2, random_state=42, stratify=y
            )

            # Scale the features
            scaler = StandardScaler()
            
X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)

            # Train model and compute log loss
            model = LogisticRegression(max_iter=5000, solver='liblinear')
            model.fit(X_train_scaled, y_train)
            preds = model.predict_proba(X_test_scaled)
            logloss = log_loss(y_test, preds)

            print(f"Feature category: {name}, Log Loss: {logloss:.4f}")

            # Update best subset if log loss improves
            if logloss < best_logloss:
                best_subset = name
                best_logloss = logloss

        # Stop if no improvement
        if best_subset is None or best_logloss >= current_logloss:
            print("\nStopping: No further improvement in log loss.")
            break

        # Add the best subset to the selected features
        print(f"\nAdding feature category: {best_subset}, Log Loss: {best_logloss:.4f}")
        selected_features.append(best_subset)
        current_logloss = best_logloss
        remaining_features.pop(best_subset)
        step += 1

    return selected_features

# Run forward stepwise selection
selected_features = forward_stepwise_selection(features, y)
print("\nSelected Features:", selected_features)

# Combine selected features for final classification
final_features = np.hstack([features[cat] for cat in selected_features])

# Train-test split using selected features
X_train, X_test, y_train, y_test = train_test_split(
    final_features, y, test_size=0.2, random_state=42, stratify=y
)

# Scale the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Classifier 1: XGBoost
xgb_classifier = XGBClassifier()
xgb_classifier.fit(X_train, y_train)
xgb_pred = xgb_classifier.predict(X_test)
print("\nXGBoost Performance")
print("Accuracy:", accuracy_score(y_test, xgb_pred))
print("Classification Report:\n", classification_report(y_test, xgb_pred))

# Classifier 2: Random Forest
rf_classifier = RandomForestClassifier()
rf_classifier.fit(X_train, y_train)
rf_pred = rf_classifier.predict(X_test)
print("\nRandom Forest Performance")
print("Accuracy:", accuracy_score(y_test, rf_pred))
print("Classification Report:\n", classification_report(y_test, rf_pred))

# Classifier 3: Support Vector Machine (SVM)
svm_classifier = SVC(probability=True)
svm_classifier.fit(X_train, y_train)
svm_pred = svm_classifier.predict(X_test)
print("\nSVM Performance")
print("Accuracy:", accuracy_score(y_test, svm_pred))
print("Classification Report:\n", classification_report(y_test, svm_pred))